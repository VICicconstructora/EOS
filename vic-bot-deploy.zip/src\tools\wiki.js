const { createClient } = require('@supabase/supabase-js')

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

async function searchWiki(query) {
  if (!query?.trim()) return 'Query vacía.'

  // Búsqueda full-text en español via PostgreSQL tsvector
  const { data, error } = await supabase
    .from('wiki_documents')
    .select('title, content, file_path')
    .textSearch('search_vector', query, {
      type: 'websearch',
      config: 'spanish'
    })
    .limit(5)

  if (error) {
    console.error('[wiki] Error búsqueda:', error.message)
    return `Error buscando en wiki: ${error.message}`
  }

  if (!data?.length) {
    // Fallback: búsqueda por ilike si FTS no devuelve nada
    const words = query.split(/\s+/).filter(w => w.length > 3)
    if (!words.length) return 'No se encontraron resultados en el wiki.'

    const fallbackFilter = words.map(w => `content.ilike.%${w}%`).join(',')
    const { data: fallback, error: fErr } = await supabase
      .from('wiki_documents')
      .select('title, content, file_path')
      .or(fallbackFilter)
      .limit(4)

    if (fErr || !fallback?.length) return 'No se encontraron resultados en el wiki.'

    return fallback.map(d => ({
      title: d.title,
      archivo: d.file_path,
      extracto: d.content.slice(0, 800)
    }))
  }

  return data.map(d => ({
    title: d.title,
    archivo: d.file_path,
    extracto: d.content.slice(0, 800)
  }))
}

module.exports = { searchWiki }
